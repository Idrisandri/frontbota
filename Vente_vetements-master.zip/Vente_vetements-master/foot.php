<section>
	<footer>
	<div class="payement">
		<a href=""><div><img src="images/livraisons.png" width="60" height="50"><span>Livraison Gratuite</span></div></a><br><br>
	 	<a href=""><div><img src="images/retours.png" width="60" height="50"><span>Retout après vente possible</span></div></a><br><br>
		<a href=""><div><img src="images/calendar.png" width="60" height="50"><span>Livraison sous 8 jours au maximum</span></div></a><br><br>
	</div>
	<div class="payement">
		
		<h3>MODE DE PAIEMENT</h3>
		<a href="" ><div><img src="images/visas.png" width="60" height="40"><span>Carte visa</span></div></a><br><br>
	 	<a href=""><div><img src="images/master.png" width="60" height="50"><span>Master Card</span></div></a><br><br>
		<a href="" ><div><img src="images/paypal2.jpg" width="60" height="40"><span>Paypal</span></div></a><br><br>
	</div>
	<div class="contact">
	
		<a href="https://www.facebook.com" target="_blank" ><div><img src="images/facebook.png" width="60" height="50"><span></span></div></a><br><br>
	 	<a href=""><div><img src="images/google.png" width="60" height="50"><span></span></div></a><br><br>
	
	</div>
	<div class="contact">
		
	 	<a href="" ><div><img src="images/apple.png" width="60" height="50"><span></span></div></a><br><br>
		<a href="" ><div><img src="images/amazon.jpg" width="60" height="50"><span></span></div></a><br><br>
		
	</div>
	<div style="text-align:center; ">
	 <p style="font-size: 20px; color: white; ">2019-Copyright Komlan Jean-Marie Dantodji</p>
	</div>
	
	</footer>
</section>

