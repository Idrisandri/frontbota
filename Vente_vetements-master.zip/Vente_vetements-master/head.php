<header>
			<h1 size="10" style="color:black; font-family:Old English Text MT; text-align:center;">Grace's Clothes</h1>

<table>
	<div>
	<tr>
		<td><a href="produits.php?produit=enfant">Enfants </a></td>
		<td><a href="produits.php?produit=chemise">Femmes </a></td>
		<td><a href="produits.php?produit=pantalon">Hommes</a></td>
	</tr>
	</div>
</table>

<div class="clien">
<a style="padding-right: 40px;"  href="compte.php" class="social"><img src="images/connetion.png" alt="se connecter" width="60" height="50"><br>Connexion</a>
<a  style="padding-right: 40px;" href="contact.php" class="social"><img src="images/contact.png" alt="contacter" width="70" height="50"><br>Nous contacter</a>
<a style="padding-right: 20px;"  href="" class="social"><img src="images/mon_panier1.png" alt="mes preferés" width="50" height="50"><br>Mon panier</a>
</div>

<br><br><br><br><br><br>
<form class="recherche" method= "get" action= "/search" autocomplete= "off">
<input name= "q" type="text" size= "15" placeholder="Rechercher" />
<input class="button" type= "submit" value=" " />
</form>
<nav class="menus">
 <ul>
 <li><a href="accueil.php">Acceuil</a></li>
 <li><a href="produits.php?produit=nouveau">Nouveautés</a></li>
 <li><a href="produits.php?produit=chemise">Chemises</a></li>
 <li><a href="produits.php?produit=chaussure">Chaussures</a></li>
 <li><a  href="produits.php?produit=pantalon">Pantalons</a></li>
 </ul>
</nav>
</header>

